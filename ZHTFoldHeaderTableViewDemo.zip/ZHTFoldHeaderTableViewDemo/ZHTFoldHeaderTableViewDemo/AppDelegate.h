//
//  AppDelegate.h
//  ZHTFoldHeaderTableViewDemo
//
//  Created by admin on 2017/7/28.
//  Copyright © 2017年 zht. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

