//
//  ViewController.m
//  ZHTFoldHeaderTableViewDemo
//
//  Created by admin on 2017/7/28.
//  Copyright © 2017年 zht. All rights reserved.
//

#import "ViewController.h"
#import "ZHTFoldHeaderTableViewController.h"

#define kScreenW [UIScreen mainScreen].bounds.size.width
#define kScreenH [UIScreen mainScreen].bounds.size.height

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0.5*kScreenH, kScreenW, 40)];
    label.text = @"点击页面";
    label.textAlignment = NSTextAlignmentCenter;
    label.font = [UIFont systemFontOfSize:20 weight:UIFontWeightBold];
    [self.view addSubview:label];
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    ZHTFoldHeaderTableViewController *t1 = [[ZHTFoldHeaderTableViewController alloc] init];
    [self presentViewController:t1 animated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
