//
//  ZHTFoldHeaderTableViewController.m
//  ZHTFoldHeaderTableViewDemo
//
//  Created by admin on 2017/8/2.
//  Copyright © 2017年 zht. All rights reserved.
//

#import "ZHTFoldHeaderTableViewController.h"
#import "ZHTFoldHeaderView.h"

@interface ZHTFoldHeaderTableViewController ()<ZHTFoldHeaderViewDelegate>

@property (nonatomic, strong) NSArray *listArray;
@property (strong, nonatomic) NSArray *secHeaderNameArray;
@property (nonatomic, assign) BOOL isOpen;
@property (nonatomic, assign) NSInteger lastSelectedSection;

@end

@implementation ZHTFoldHeaderTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    NSString *plistPath = [[NSBundle mainBundle] pathForResource:@"ZHTFoldHeaderTableViewDataSource" ofType:@"plist"];
    
    self.listArray = [NSArray arrayWithContentsOfFile:plistPath];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.listArray.count;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 50;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (self.isOpen && self.lastSelectedSection == section){
        return [self.listArray[section][@"groupArray"] count];
    }
    return 0;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.isOpen && self.lastSelectedSection == indexPath.section){
        return 60;
    }
    return 0;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    NSString *headerID = [NSString stringWithFormat:@"headerID%ld", (long)section];
    ZHTFoldHeaderView *view = [tableView dequeueReusableHeaderFooterViewWithIdentifier:headerID];
    if (!view) {
        view = [[ZHTFoldHeaderView alloc] initWithReuseIdentifier:headerID];
        view.tag = section;
        view.delegate = self;
        view.name = self.listArray[section][@"headerName"];
        view.headerImageName = self.listArray[section][@"headerImageName"];
    }
    return view;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"cellID";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
    }
    
    cell.textLabel.text = self.listArray[indexPath.section][@"groupArray"][indexPath.row][@"rowTitle"];
    
    cell.detailTextLabel.text = self.listArray[indexPath.section][@"groupArray"][indexPath.row][@"rowSubTitle"];
    
    cell.imageView.image = [UIImage imageNamed:self.listArray[indexPath.section][@"groupArray"][indexPath.row][@"rowImageName"]];
    
    return cell;
}

//点击sectionHeaderView
-(void)didSelectHeaderView:(ZHTFoldHeaderView *)headerView
{
    if (self.isOpen && self.lastSelectedSection != headerView.tag) {
        self.isOpen = NO;
        // 先收起之前组的箭头
        ZHTFoldHeaderView *view = (ZHTFoldHeaderView *)[self.tableView headerViewForSection:self.lastSelectedSection];
        [view changeHeaderArrowWithIsOpen:NO];
        // 删除所展开的cell
        NSMutableArray *deleteArray = [[NSMutableArray alloc] init];
        for (int i = 0; i < [self.listArray[self.lastSelectedSection][@"groupArray"] count]; i++) {
            NSIndexPath *deleteIndexPath = [NSIndexPath indexPathForRow:i inSection:self.lastSelectedSection];
            [deleteArray addObject:deleteIndexPath];
        }
        [self.tableView deleteRowsAtIndexPaths:deleteArray withRowAnimation:UITableViewRowAnimationAutomatic];
    }
    // 2.点击同一组处理
    if (self.isOpen && self.lastSelectedSection == headerView.tag) {
        self.isOpen = NO;
        // 删除所展开的cell
        NSMutableArray *deleteArray = [[NSMutableArray alloc] init];
        for (int i = 0; i < [self.listArray[self.lastSelectedSection][@"groupArray"] count]; i++) {
            NSIndexPath *deleteIndexPath = [NSIndexPath indexPathForRow:i inSection:self.lastSelectedSection];
            [deleteArray addObject:deleteIndexPath];
        }
        [self.tableView deleteRowsAtIndexPaths:deleteArray withRowAnimation:UITableViewRowAnimationAutomatic];
        return ;
    }
    // 3.展开所点击的组(非同一组)
    self.isOpen = YES;
    self.lastSelectedSection = headerView.tag;
    
    NSMutableArray *insertArray = [[NSMutableArray alloc] init];
    for (int i = 0; i<[self.listArray[self.lastSelectedSection][@"groupArray"] count]; i++) {
        NSIndexPath *deleteIndexPath = [NSIndexPath indexPathForRow:i inSection:self.lastSelectedSection];
        [insertArray addObject:deleteIndexPath];
    }
    [self.tableView insertRowsAtIndexPaths:insertArray withRowAnimation:UITableViewRowAnimationAutomatic];
}

@end
