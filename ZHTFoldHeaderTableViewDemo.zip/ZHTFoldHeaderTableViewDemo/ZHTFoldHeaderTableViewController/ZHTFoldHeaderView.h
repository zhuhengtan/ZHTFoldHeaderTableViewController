//
//  ZHTFoldHeaderView.h
//  ZHTFoldHeaderTableViewDemo
//
//  Created by admin on 2017/8/1.
//  Copyright © 2017年 zht. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kScreenW [UIScreen mainScreen].bounds.size.width
#define kScreenH [UIScreen mainScreen].bounds.size.height

@class ZHTFoldHeaderView;

@protocol ZHTFoldHeaderViewDelegate <NSObject>

- (void)didSelectHeaderView:(ZHTFoldHeaderView *)headerView;

@end

@interface ZHTFoldHeaderView : UITableViewHeaderFooterView

@property(strong, nonatomic) NSString *name;
@property(strong, nonatomic) NSString *headerImageName;

@property (nonatomic, weak) id<ZHTFoldHeaderViewDelegate>delegate;

- (void)changeHeaderArrowWithIsOpen:(BOOL)isOpen;

@end


#pragma mark UIView ZHTAdditions

@interface UIView (ZHTAdditions)

@property (assign, nonatomic) CGFloat x;
@property (assign, nonatomic) CGFloat y;
@property (assign, nonatomic) CGFloat width;
@property (assign, nonatomic) CGFloat height;
@property (nonatomic, assign) CGFloat centerX;
@property (nonatomic, assign) CGFloat centerY;
@property (assign, nonatomic) CGSize size;
@property (assign, nonatomic) CGPoint origin;

@end
