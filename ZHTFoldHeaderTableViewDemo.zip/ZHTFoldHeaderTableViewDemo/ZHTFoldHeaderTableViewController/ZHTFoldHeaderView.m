//
//  ZHTFoldHeaderView.m
//  ZHTFoldHeaderTableViewDemo
//
//  Created by admin on 2017/8/1.
//  Copyright © 2017年 zht. All rights reserved.
//

#import "ZHTFoldHeaderView.h"

#define kFolderHeaderMarkW 18

@interface ZHTFoldHeaderView ()

@property(strong, nonatomic) UILabel *headerTitle;
@property (nonatomic, strong) UIImageView *arrow;
@property (strong, nonatomic) UIView *line;
@property(strong, nonatomic) UIImageView *icon;
@property (nonatomic, assign) BOOL isUnfold;

@end

@implementation ZHTFoldHeaderView

-(instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithReuseIdentifier:reuseIdentifier]) {
        self.contentView.backgroundColor = [UIColor whiteColor];
        [self buildUI];
    }
    return self;
}

-(void)buildUI
{

    self.icon = [[UIImageView alloc] initWithFrame:CGRectMake(8, 19, kFolderHeaderMarkW, kFolderHeaderMarkW)];
    self.icon.contentMode = UIViewContentModeScaleAspectFill;
    
    self.headerTitle = [[UILabel alloc] initWithFrame:CGRectMake(0, _icon.y, kScreenW, kFolderHeaderMarkW)];
    
    [self.headerTitle setTextAlignment:NSTextAlignmentCenter];
    self.headerTitle.font = [UIFont systemFontOfSize:15 weight:UIFontWeightThin];
    
    self.line = [[UIView alloc] initWithFrame:CGRectMake(0, _icon.y + kFolderHeaderMarkW + 8, kScreenW, 5)];
    self.line.backgroundColor = [UIColor lightGrayColor];
    

    self.arrow = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 14, 8)];
    self.arrow.image = [UIImage imageNamed:@"foldHeader_down.png"];
    self.arrow.y = _icon.centerY;
    self.arrow.x = kScreenW - 28;
    
    [self.contentView addSubview:self.icon];
    [self.contentView addSubview:self.headerTitle];
    [self.contentView addSubview:self.line];
    [self.contentView addSubview:self.arrow];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapHeader)];
    [self.contentView addGestureRecognizer:tap];
}

- (void)tapHeader {
    // 修改箭头方向
    [self changeArrowDirection];
    if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectHeaderView:)]) {
        [self.delegate didSelectHeaderView:self];
    }
}
- (void)changeArrowDirection {
    self.isUnfold = !self.isUnfold;
    NSString *arrowType = self.isUnfold ? @"foldHeader_up.png" : @"foldHeader_down.png";
    self.arrow.image = [UIImage imageNamed:arrowType];
}
- (void)changeHeaderArrowWithIsOpen:(BOOL)isOpen {
    self.isUnfold = isOpen;
    NSString *arrowType = isOpen ? @"foldHeader_up.png" : @"foldHeader_down.png";
    self.arrow.image = [UIImage imageNamed:arrowType];
}

-(void)setName:(NSString *)name
{
    self.headerTitle.text = name;
}

-(void)setHeaderImageName:(NSString *)headerImageName{
    
    self.icon.image = [UIImage imageNamed:headerImageName];
}

@end





#pragma mark UIView ZHTAdditions
@implementation UIView (ZHTAdditions)

- (void)setX:(CGFloat)x
{
    CGRect frame = self.frame;
    frame.origin.x = x;
    self.frame = frame;
}

- (CGFloat)x
{
    return self.frame.origin.x;
}

- (void)setY:(CGFloat)y
{
    CGRect frame = self.frame;
    frame.origin.y = y;
    self.frame = frame;
}

- (CGFloat)y
{
    return self.frame.origin.y;
}

- (void)setCenterX:(CGFloat)centerX
{
    CGPoint center = self.center;
    center.x = centerX;
    self.center = center;
}

- (CGFloat)centerX
{
    return self.center.x;
}

- (void)setCenterY:(CGFloat)centerY
{
    CGPoint center = self.center;
    center.y = centerY;
    self.center = center;
}

- (CGFloat)centerY
{
    return self.center.y;
}

- (void)setWidth:(CGFloat)width
{
    CGRect frame = self.frame;
    frame.size.width = width;
    self.frame = frame;
}

- (CGFloat)width
{
    return self.frame.size.width;
}

- (void)setHeight:(CGFloat)height
{
    CGRect frame = self.frame;
    frame.size.height = height;
    self.frame = frame;
}

- (CGFloat)height
{
    return self.frame.size.height;
}

- (void)setSize:(CGSize)size
{
    CGRect frame = self.frame;
    frame.size = size;
    self.frame = frame;
}

- (CGSize)size
{
    return self.frame.size;
}

- (void)setOrigin:(CGPoint)origin
{
    CGRect frame = self.frame;
    frame.origin = origin;
    self.frame = frame;
}

- (CGPoint)origin
{
    return self.frame.origin;
}

@end
